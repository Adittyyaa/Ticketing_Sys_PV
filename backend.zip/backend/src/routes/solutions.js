import { Router } from 'express'
import { requireAuth, requireAdmin } from '../lib/auth.js'
import { 
  createSolution, 
  getSolutions,
  incrementSolutionViews,
  incrementSolutionHelpful
} from '../lib/database-service.js'

const router = Router()

// Get all published solutions (public endpoint)
router.get('/', async (req, res) => {
  try {
    const solutions = await getSolutions(true) // Only published solutions

    res.json({
      success: true,
      solutions
    })
  } catch (error) {
    console.error('Get solutions error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Get all solutions (admin only - includes unpublished)
router.get('/all', async (req, res) => {
  try {
    await requireAdmin(req.headers.authorization)
    
    const solutions = await getSolutions() // All solutions

    res.json({
      success: true,
      solutions
    })
  } catch (error) {
    console.error('Get all solutions error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Get single solution by ID
router.get('/:id', async (req, res) => {
  try {
    const solutionId = req.params.id
    
    // Get all solutions and find the specific one
    const solutions = await getSolutions(true)
    const solution = solutions.find(s => s.id === solutionId)

    if (!solution) {
      return res.status(404).json({ 
        error: 'Solution not found' 
      })
    }

    // Increment view count
    await incrementSolutionViews(solutionId)

    res.json({
      success: true,
      solution
    })
  } catch (error) {
    console.error('Get solution error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Create new solution (authenticated users)
router.post('/', async (req, res) => {
  try {
    const user = await requireAuth(req.headers.authorization)
    const solutionData = req.body

    if (!solutionData.title || !solutionData.description || !solutionData.steps) {
      return res.status(400).json({ 
        error: 'Title, description, and steps are required' 
      })
    }

    // Only admins can publish solutions directly
    if (solutionData.is_published && user.role !== 'admin') {
      solutionData.is_published = false
    }

    const solution = await createSolution(user.id, solutionData)

    res.status(201).json({
      success: true,
      solution
    })
  } catch (error) {
    console.error('Create solution error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Mark solution as helpful
router.post('/:id/helpful', async (req, res) => {
  try {
    const solutionId = req.params.id
    
    // Check if solution exists
    const solutions = await getSolutions(true)
    const solution = solutions.find(s => s.id === solutionId)

    if (!solution) {
      return res.status(404).json({ 
        error: 'Solution not found' 
      })
    }

    await incrementSolutionHelpful(solutionId)

    res.json({
      success: true,
      message: 'Solution marked as helpful'
    })
  } catch (error) {
    console.error('Mark solution helpful error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Search solutions
router.get('/search/:query', async (req, res) => {
  try {
    const searchTerm = req.params.query.toLowerCase()
    const solutions = await getSolutions(true)

    // Simple text search in title, description, and steps
    const filteredSolutions = solutions.filter(solution => 
      solution.title.toLowerCase().includes(searchTerm) ||
      solution.description.toLowerCase().includes(searchTerm) ||
      solution.steps.some(step => step.toLowerCase().includes(searchTerm)) ||
      solution.tags.some(tag => tag.toLowerCase().includes(searchTerm))
    )

    res.json({
      success: true,
      solutions: filteredSolutions,
      searchTerm
    })
  } catch (error) {
    console.error('Search solutions error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Get solutions by category
router.get('/category/:categoryId', async (req, res) => {
  try {
    const categoryId = req.params.categoryId
    const solutions = await getSolutions(true)

    const filteredSolutions = solutions.filter(solution => 
      solution.category_id === categoryId
    )

    res.json({
      success: true,
      solutions: filteredSolutions,
      categoryId
    })
  } catch (error) {
    console.error('Get solutions by category error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Get solutions by tag
router.get('/tag/:tag', async (req, res) => {
  try {
    const tag = req.params.tag.toLowerCase()
    const solutions = await getSolutions(true)

    const filteredSolutions = solutions.filter(solution => 
      solution.tags.some(t => t.toLowerCase() === tag)
    )

    res.json({
      success: true,
      solutions: filteredSolutions,
      tag
    })
  } catch (error) {
    console.error('Get solutions by tag error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

