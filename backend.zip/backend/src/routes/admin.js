import { Router } from 'express'
import { adminController } from '../controllers/adminController.js'
import { requireAdmin } from '../middleware/auth.js'
import { 
  validatePagination, 
  sanitizeInput 
} from '../middleware/validation.js'

const router = Router()

// All admin routes require admin authentication
router.use(requireAdmin)

// ============================================
// TICKET MANAGEMENT
// ============================================

// Get all tickets (admin view)
router.get('/tickets', 
  validatePagination,
  adminController.getAllTickets
)

// Get single ticket (admin view)
router.get('/tickets/:id', 
  adminController.getTicketById
)

// Update ticket (admin view)
router.put('/tickets/:id', 
  sanitizeInput,
  adminController.updateTicket
)

// Delete ticket (admin only)
router.delete('/tickets/:id', 
  adminController.deleteTicket
)

// Bulk delete tickets
router.post('/tickets/bulk-delete', 
  sanitizeInput,
  adminController.bulkDeleteTickets
)

// Assign ticket
router.post('/tickets/:id/assign', 
  sanitizeInput,
  adminController.assignTicket
)

// ============================================
// USER MANAGEMENT
// ============================================

// Get all users
router.get('/users', 
  validatePagination,
  adminController.getAllUsers
)

// Get single user
router.get('/users/:id', 
  adminController.getUserById
)

// Update user
router.put('/users/:id', 
  sanitizeInput,
  adminController.updateUser
)

// Update user role
router.put('/users/:id/role', 
  sanitizeInput,
  adminController.updateUserRole
)

// Delete user
router.delete('/users/:id', 
  adminController.deleteUser
)

// Verify user email
router.post('/users/:id/verify-email', 
  adminController.verifyUserEmail
)

// ============================================
// ANALYTICS & REPORTS
// ============================================

// Get dashboard statistics
router.get('/dashboard/stats', 
  adminController.getDashboardStats
)

// Get recent activity
router.get('/dashboard/activity', 
  adminController.getRecentActivity
)

// ============================================
// SYSTEM MANAGEMENT
// ============================================

// Get system health
router.get('/system/health', 
  adminController.getSystemHealth
)

export default router