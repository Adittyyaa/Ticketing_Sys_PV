/**
 * Routes index for centralized route management
 * This file serves as the central export point for all routes
 */

import { Router } from 'express'

// Import individual route modules
import authRoutes from './auth.js'
import ticketRoutes from './tickets.js'
import adminRoutes from './admin.js'
import solutionRoutes from './solutions.js'
import feedbackRoutes from './feedback.js'

// Create main router
const router = Router()

// ============================================
// API ROUTE MOUNTING
// ============================================

// Authentication routes
router.use('/auth', authRoutes)

// Ticket management routes
router.use('/tickets', ticketRoutes)

// Administrative routes
router.use('/admin', adminRoutes)

// Knowledge base solutions
router.use('/solutions', solutionRoutes)

// User feedback routes
router.use('/feedback', feedbackRoutes)

// ============================================
// ROUTE HEALTH CHECK
// ============================================

router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    routes: {
      auth: '/api/auth',
      tickets: '/api/tickets',
      admin: '/api/admin',
      solutions: '/api/solutions',
      feedback: '/api/feedback'
    },
    version: process.env.npm_package_version || '1.0.0'
  })
})

// ============================================
// ROUTE DOCUMENTATION ENDPOINT
// ============================================

router.get('/docs', (req, res) => {
  res.json({
    title: 'PV Advisory Ticketing System API',
    version: process.env.npm_package_version || '1.0.0',
    endpoints: {
      auth: {
        base: '/api/auth',
        endpoints: [
          'POST /login',
          'POST /register',
          'POST /logout',
          'GET /validate-token',
          'POST /change-password',
          'POST /request-password-reset',
          'POST /reset-password',
          'GET /profile'
        ]
      },
      tickets: {
        base: '/api/tickets',
        endpoints: [
          'GET /',
          'POST /',
          'GET /:id',
          'PUT /:id',
          'DELETE /:id',
          'POST /:id/comments',
          'GET /:id/comments',
          'PUT /:id/status',
          'PUT /:id/assign'
        ]
      },
      admin: {
        base: '/api/admin',
        endpoints: [
          'GET /dashboard/stats',
          'GET /users',
          'POST /users',
          'PUT /users/:id',
          'DELETE /users/:id',
          'GET /settings',
          'PUT /settings'
        ]
      },
      solutions: {
        base: '/api/solutions',
        endpoints: [
          'GET /',
          'POST /',
          'GET /:id',
          'PUT /:id',
          'DELETE /:id'
        ]
      },
      feedback: {
        base: '/api/feedback',
        endpoints: [
          'GET /',
          'POST /',
          'GET /:id',
          'PUT /:id/status'
        ]
      }
    }
  })
})

export default router

// Export individual route modules for direct use if needed
export {
  authRoutes,
  ticketRoutes,
  adminRoutes,
  solutionRoutes,
  feedbackRoutes
}