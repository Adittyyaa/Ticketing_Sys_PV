import { Router } from 'express'
import { requireAuth } from '../lib/auth.js'
import { safeQuery } from '../lib/database.js'

const router = Router()

// Submit feedback
router.post('/', async (req, res) => {
  try {
    const user = await requireAuth(req.headers.authorization)
    const { ticket_id, solution_id, rating, comment } = req.body

    // Validate input
    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ 
        error: 'Rating must be between 1 and 5'
      })
    }

    if (!ticket_id && !solution_id) {
      return res.status(400).json({ 
        error: 'Either ticket_id or solution_id is required'
      })
    }

    // Create feedback entry
    const result = await safeQuery(
      `INSERT INTO feedback (user_id, ticket_id, solution_id, rating, comment)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        user.id,
        ticket_id || null,
        solution_id || null,
        rating,
        comment || null
      ]
    )

    const feedback = result.rows[0]

    res.status(201).json({
      success: true,
      feedback: {
        id: feedback.id,
        rating: feedback.rating,
        comment: feedback.comment,
        created_at: feedback.created_at
      },
      message: 'Feedback submitted successfully'
    })
  } catch (error) {
    console.error('Submit feedback error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Get feedback for a ticket (authenticated users)
router.get('/ticket/:ticketId', async (req, res) => {
  try {
    await requireAuth(req.headers.authorization)
    const ticketId = req.params.ticketId

    const result = await safeQuery(
      `SELECT f.*, u.full_name as user_name
       FROM feedback f
       LEFT JOIN users u ON f.user_id = u.id
       WHERE f.ticket_id = $1
       ORDER BY f.created_at DESC`,
      [ticketId]
    )

    res.json({
      success: true,
      feedback: result.rows,
      ticketId
    })
  } catch (error) {
    console.error('Get ticket feedback error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Get feedback for a solution
router.get('/solution/:solutionId', async (req, res) => {
  try {
    const solutionId = req.params.solutionId

    const result = await safeQuery(
      `SELECT f.*, u.full_name as user_name
       FROM feedback f
       LEFT JOIN users u ON f.user_id = u.id
       WHERE f.solution_id = $1 AND f.comment IS NOT NULL
       ORDER BY f.created_at DESC
       LIMIT 50`,
      [solutionId]
    )

    // Calculate average rating
    const ratingResult = await safeQuery(
      `SELECT AVG(rating::decimal) as avg_rating, COUNT(*) as total_count
       FROM feedback
       WHERE solution_id = $1`,
      [solutionId]
    )

    const stats = ratingResult.rows[0]

    res.json({
      success: true,
      feedback: result.rows,
      stats: {
        averageRating: parseFloat(stats.avg_rating) || 0,
        totalRatings: parseInt(stats.total_count) || 0
      },
      solutionId
    })
  } catch (error) {
    console.error('Get solution feedback error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Get user's feedback history
router.get('/my-feedback', async (req, res) => {
  try {
    const user = await requireAuth(req.headers.authorization)

    const result = await safeQuery(
      `SELECT f.*, 
              t.title as ticket_title,
              s.title as solution_title
       FROM feedback f
       LEFT JOIN tickets t ON f.ticket_id = t.id
       LEFT JOIN solutions s ON f.solution_id = s.id
       WHERE f.user_id = $1
       ORDER BY f.created_at DESC`,
      [user.id]
    )

    res.json({
      success: true,
      feedback: result.rows
    })
  } catch (error) {
    console.error('Get user feedback error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Update feedback (user can only update their own)
router.put('/:id', async (req, res) => {
  try {
    const user = await requireAuth(req.headers.authorization)
    const feedbackId = req.params.id
    const { rating, comment } = req.body

    // Validate input
    if (rating && (rating < 1 || rating > 5)) {
      return res.status(400).json({ 
        error: 'Rating must be between 1 and 5'
      })
    }

    // Check if feedback exists and belongs to user
    const existingResult = await safeQuery(
      'SELECT * FROM feedback WHERE id = $1 AND user_id = $2',
      [feedbackId, user.id]
    )

    if (existingResult.rows.length === 0) {
      return res.status(404).json({ 
        error: 'Feedback not found or access denied'
      })
    }

    // Build update query
    const fields = []
    const values = []
    let paramIndex = 1

    if (rating !== undefined) {
      fields.push(`rating = $${paramIndex++}`)
      values.push(rating)
    }

    if (comment !== undefined) {
      fields.push(`comment = $${paramIndex++}`)
      values.push(comment)
    }

    if (fields.length === 0) {
      return res.status(400).json({ 
        error: 'No fields to update' 
      })
    }

    values.push(feedbackId, user.id)

    const result = await safeQuery(
      `UPDATE feedback 
       SET ${fields.join(', ')}, updated_at = NOW()
       WHERE id = $${paramIndex++} AND user_id = $${paramIndex++}
       RETURNING *`,
      values
    )

    res.json({
      success: true,
      feedback: result.rows[0],
      message: 'Feedback updated successfully'
    })
  } catch (error) {
    console.error('Update feedback error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Delete feedback (user can only delete their own)
router.delete('/:id', async (req, res) => {
  try {
    const user = await requireAuth(req.headers.authorization)
    const feedbackId = req.params.id

    // Check if feedback exists and belongs to user
    const existingResult = await safeQuery(
      'SELECT * FROM feedback WHERE id = $1 AND user_id = $2',
      [feedbackId, user.id]
    )

    if (existingResult.rows.length === 0) {
      return res.status(404).json({ 
        error: 'Feedback not found or access denied'
      })
    }

    await safeQuery(
      'DELETE FROM feedback WHERE id = $1 AND user_id = $2',
      [feedbackId, user.id]
    )

    res.json({
      success: true,
      message: 'Feedback deleted successfully'
    })
  } catch (error) {
    console.error('Delete feedback error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

// Get feedback statistics (for admin dashboard)
router.get('/stats/overview', async (req, res) => {
  try {
    const user = await requireAuth(req.headers.authorization)
    
    // Only allow admins to see full stats
    if (user.role !== 'admin') {
      return res.status(403).json({ 
        error: 'Admin access required'
      })
    }

    const result = await safeQuery(
      `SELECT 
         COUNT(*) as total_feedback,
         AVG(rating::decimal) as avg_rating,
         COUNT(CASE WHEN created_at >= date_trunc('month', CURRENT_DATE) THEN 1 END) as feedback_this_month,
         (SELECT s.title FROM feedback f2 
          LEFT JOIN solutions s ON f2.solution_id = s.id 
          WHERE f2.solution_id IS NOT NULL 
          GROUP BY s.id, s.title 
          ORDER BY COUNT(*) DESC 
          LIMIT 1) as most_rated_solution
       FROM feedback`,
      []
    )

    const stats = result.rows[0]

    res.json({
      success: true,
      stats: {
        totalFeedback: parseInt(stats.total_feedback) || 0,
        averageRating: parseFloat(stats.avg_rating) || 0,
        feedbackThisMonth: parseInt(stats.feedback_this_month) || 0,
        mostRatedSolution: stats.most_rated_solution
      }
    })
  } catch (error) {
    console.error('Get feedback stats error:', error)
    res.status(500).json({ 
      error: 'Internal server error'
    })
  }
})

export default router