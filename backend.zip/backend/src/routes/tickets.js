import { Router } from 'express'
import { ticketController } from '../controllers/ticketController.js'
import { authenticate, requireAgent } from '../middleware/auth.js'
import { 
  validateTicketCreation, 
  validatePagination, 
  sanitizeInput 
} from '../middleware/validation.js'

const router = Router()

// All ticket routes require authentication
router.use(authenticate)

// ============================================
// TICKET CRUD OPERATIONS
// ============================================

// Get tickets with pagination and filters
router.get('/', 
  validatePagination,
  ticketController.getTickets
)

// Search tickets
router.get('/search', 
  validatePagination,
  ticketController.searchTickets
)

// Get analytics (for agents/admins only)
router.get('/analytics', 
  requireAgent,
  ticketController.getTicketAnalytics
)

// Get recent tickets (for agents/admins only)
router.get('/recent', 
  requireAgent,
  ticketController.getRecentTickets
)

// Get current user's tickets
router.get('/my-tickets', 
  validatePagination,
  ticketController.getUserTickets
)

// Get tickets assigned to current user (for agents/admins)
router.get('/assigned-to-me', 
  requireAgent,
  validatePagination,
  ticketController.getAssignedTickets
)

// Get single ticket by ID
router.get('/:id', 
  ticketController.getTicketById
)

// Create new ticket
router.post('/', 
  sanitizeInput,
  validateTicketCreation,
  ticketController.createTicket
)

// Update ticket
router.put('/:id', 
  sanitizeInput,
  ticketController.updateTicket
)

// Delete ticket
router.delete('/:id', 
  ticketController.deleteTicket
)

// Assign ticket (for agents/admins only)
router.post('/:id/assign', 
  requireAgent,
  sanitizeInput,
  ticketController.assignTicket
)

export default router