import { Router } from 'express'
import { authController } from '../controllers/authController.js'
import { authenticate } from '../middleware/auth.js'
import { 
  validateLogin, 
  validateUserRegistration, 
  sanitizeInput 
} from '../middleware/validation.js'

const router = Router()

// ============================================
// AUTHENTICATION ROUTES
// ============================================

// Login
router.post('/login', 
  sanitizeInput,
  validateLogin,
  authController.login
)

// Register
router.post('/register', 
  sanitizeInput,
  validateUserRegistration,
  authController.register
)

// Logout
router.post('/logout', authController.logout)

// Validate token
router.get('/validate', 
  authenticate,
  authController.validateToken
)

// ============================================
// PASSWORD OPERATIONS
// ============================================

// Change password (requires authentication)
router.post('/change-password', 
  authenticate,
  sanitizeInput,
  authController.changePassword
)

// Request password reset
router.post('/reset-password-request', 
  sanitizeInput,
  authController.requestPasswordReset
)

// Reset password with token
router.post('/reset-password', 
  sanitizeInput,
  authController.resetPassword
)

// ============================================
// USER PROFILE
// ============================================

// Get current user profile
router.get('/profile', 
  authenticate,
  authController.getProfile
)

// Legacy endpoint for backwards compatibility
router.get('/me', 
  authenticate,
  authController.getProfile
)

export default router