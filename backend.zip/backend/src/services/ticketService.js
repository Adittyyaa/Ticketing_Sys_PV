import { safeQuery } from '../lib/database.js'

class TicketService {
  // ============================================
  // TICKET CRUD OPERATIONS
  // ============================================

  async createTicket(userId, ticketData) {
    const result = await safeQuery(
      `INSERT INTO tickets (user_id, title, description, category_id, type_id, product, 
                           product_reference_number, priority, tags)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        userId,
        ticketData.title,
        ticketData.description,
        ticketData.category_id || null,
        ticketData.type_id || null,
        ticketData.product || null,
        ticketData.product_reference_number || null,
        ticketData.priority || 'MEDIUM',
        ticketData.tags || []
      ]
    )
    return result.rows[0]
  }

  async getTicketById(ticketId) {
    const result = await safeQuery(
      'SELECT * FROM ticket_details WHERE id = $1',
      [ticketId]
    )
    return result.rows[0] || null
  }

  async getTickets(page = 1, limit = 20, filters = {}) {
    const offset = (page - 1) * limit
    const conditions = []
    const values = []
    let paramIndex = 1

    // Build where conditions
    if (filters.status) {
      conditions.push(`status = $${paramIndex++}`)
      values.push(filters.status)
    }
    if (filters.priority) {
      conditions.push(`priority = $${paramIndex++}`)
      values.push(filters.priority)
    }
    if (filters.category_id) {
      conditions.push(`category_id = $${paramIndex++}`)
      values.push(filters.category_id)
    }
    if (filters.user_id) {
      conditions.push(`user_id = $${paramIndex++}`)
      values.push(filters.user_id)
    }
    if (filters.assigned_to) {
      conditions.push(`assigned_to = $${paramIndex++}`)
      values.push(filters.assigned_to)
    }
    if (filters.search) {
      conditions.push(`(title ILIKE $${paramIndex} OR description ILIKE $${paramIndex})`)
      values.push(`%${filters.search}%`)
      paramIndex++
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : ''

    // Get total count
    const countResult = await safeQuery(
      `SELECT COUNT(*) as count FROM tickets ${whereClause}`,
      values
    )
    const total = parseInt(countResult.rows[0].count)

    // Get tickets
    const ticketsResult = await safeQuery(
      `SELECT * FROM ticket_details 
       ${whereClause}
       ORDER BY created_at DESC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`,
      [...values, limit, offset]
    )

    return {
      data: ticketsResult.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    }
  }

  async updateTicket(ticketId, ticketData) {
    const fields = []
    const values = []
    let paramIndex = 1

    // Define allowed fields for update
    const allowedFields = [
      'title', 'description', 'status', 'priority', 'category_id', 
      'type_id', 'assigned_to', 'tags', 'product', 'product_reference_number'
    ]

    allowedFields.forEach(field => {
      if (ticketData[field] !== undefined) {
        fields.push(`${field} = $${paramIndex++}`)
        values.push(ticketData[field])
      }
    })

    if (fields.length === 0) {
      return await this.getTicketById(ticketId) // Return current ticket if no updates
    }

    values.push(ticketId)

    const result = await safeQuery(
      `UPDATE tickets SET ${fields.join(', ')}, updated_at = NOW()
       WHERE id = $${paramIndex}
       RETURNING *`,
      values
    )
    return result.rows[0]
  }

  async deleteTicket(ticketId) {
    const result = await safeQuery(
      'DELETE FROM tickets WHERE id = $1 RETURNING *',
      [ticketId]
    )
    return result.rows[0]
  }

  async bulkDeleteTickets(ticketIds) {
    const placeholders = ticketIds.map((_, index) => `$${index + 1}`).join(', ')
    const result = await safeQuery(
      `DELETE FROM tickets WHERE id IN (${placeholders}) RETURNING id`,
      ticketIds
    )
    return result.rows
  }

  // ============================================
  // TICKET QUERIES & ANALYTICS
  // ============================================

  async searchTickets(searchTerm, filters = {}, page = 1, limit = 20) {
    const offset = (page - 1) * limit
    const conditions = ['(title ILIKE $1 OR description ILIKE $1)']
    const values = [`%${searchTerm}%`]
    let paramIndex = 2

    // Add additional filters
    if (filters.status) {
      conditions.push(`status = $${paramIndex++}`)
      values.push(filters.status)
    }
    if (filters.priority) {
      conditions.push(`priority = $${paramIndex++}`)
      values.push(filters.priority)
    }
    if (filters.user_id) {
      conditions.push(`user_id = $${paramIndex++}`)
      values.push(filters.user_id)
    }

    const whereClause = `WHERE ${conditions.join(' AND ')}`

    // Get total count
    const countResult = await safeQuery(
      `SELECT COUNT(*) as count FROM tickets ${whereClause}`,
      values
    )
    const total = parseInt(countResult.rows[0].count)

    // Get tickets
    const ticketsResult = await safeQuery(
      `SELECT * FROM ticket_details 
       ${whereClause}
       ORDER BY created_at DESC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`,
      [...values, limit, offset]
    )

    return {
      data: ticketsResult.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    }
  }

  async getTicketAnalytics() {
    const result = await safeQuery(`
      SELECT 
        COUNT(*) as total_tickets,
        COUNT(CASE WHEN status = 'OPEN' THEN 1 END) as open_tickets,
        COUNT(CASE WHEN status = 'IN_PROGRESS' THEN 1 END) as in_progress_tickets,
        COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END) as resolved_tickets,
        COUNT(CASE WHEN status = 'CLOSED' THEN 1 END) as closed_tickets,
        COUNT(CASE WHEN priority = 'HIGH' THEN 1 END) as high_priority,
        COUNT(CASE WHEN priority = 'MEDIUM' THEN 1 END) as medium_priority,
        COUNT(CASE WHEN priority = 'LOW' THEN 1 END) as low_priority,
        COUNT(CASE WHEN created_at >= NOW() - INTERVAL '24 hours' THEN 1 END) as tickets_today,
        COUNT(CASE WHEN created_at >= NOW() - INTERVAL '7 days' THEN 1 END) as tickets_this_week,
        COUNT(CASE WHEN created_at >= NOW() - INTERVAL '30 days' THEN 1 END) as tickets_this_month
      FROM tickets
    `)

    return result.rows[0]
  }

  async getTicketsByCategory() {
    const result = await safeQuery(`
      SELECT 
        c.name as category_name,
        COUNT(t.id) as ticket_count
      FROM categories c
      LEFT JOIN tickets t ON c.id = t.category_id
      GROUP BY c.id, c.name
      ORDER BY ticket_count DESC
    `)

    return result.rows
  }

  async getTicketsByAgent() {
    const result = await safeQuery(`
      SELECT 
        u.full_name,
        u.email,
        COUNT(t.id) as assigned_tickets,
        COUNT(CASE WHEN t.status = 'RESOLVED' THEN 1 END) as resolved_tickets,
        COUNT(CASE WHEN t.status = 'CLOSED' THEN 1 END) as closed_tickets
      FROM users u
      LEFT JOIN tickets t ON u.id = t.assigned_to
      WHERE u.role IN ('agent', 'admin')
      GROUP BY u.id, u.full_name, u.email
      ORDER BY assigned_tickets DESC
    `)

    return result.rows
  }

  async getUserTickets(userId, page = 1, limit = 20, filters = {}) {
    const userFilters = { ...filters, user_id: userId }
    return await this.getTickets(page, limit, userFilters)
  }

  async assignTicket(ticketId, agentId) {
    const result = await safeQuery(
      `UPDATE tickets 
       SET assigned_to = $1, 
           status = CASE WHEN status = 'OPEN' THEN 'IN_PROGRESS' ELSE status END,
           updated_at = NOW()
       WHERE id = $2 
       RETURNING *`,
      [agentId, ticketId]
    )

    if (!result.rows[0]) {
      throw new Error('Ticket not found')
    }

    return result.rows[0]
  }

  async getRecentTickets(limit = 10) {
    const result = await safeQuery(
      `SELECT * FROM ticket_details 
       ORDER BY created_at DESC 
       LIMIT $1`,
      [limit]
    )

    return result.rows
  }

  async getTicketsAssignedTo(agentId, page = 1, limit = 20) {
    const filters = { assigned_to: agentId }
    return await this.getTickets(page, limit, filters)
  }
}

export const ticketService = new TicketService()