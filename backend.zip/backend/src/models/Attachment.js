import { DataTypes } from 'sequelize';
import sequelize from '../lib/database.js';

const Attachment = sequelize.define(
  "Tbl_Attachment",
  {
    AttachmentId: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    TicketId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: { model: "Tbl_Ticket", key: "TicketId" },
    },
    UserId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: { model: "Tbl_User", key: "UserId" },
    },
    FileName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    FilePath: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    FileSize: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    FileType: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    MimeType: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    Is_Active: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

export default Attachment;