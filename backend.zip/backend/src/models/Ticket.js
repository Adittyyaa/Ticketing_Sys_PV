import { DataTypes } from 'sequelize';
import sequelize from '../lib/database.js';

const Ticket = sequelize.define(
  "Tbl_Ticket",
  {
    TicketId: {
      type: Sequelize.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    Number: {
      type: Sequelize.INTEGER,
      allowNull: false,
      unique: true,
      autoIncrement: true,
    },
    UserId: {
      type: Sequelize.BIGINT,
      allowNull: false,
      references: { model: "Tbl_User", key: "UserId" },
    },
    Title: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    Description: {
      type: Sequelize.TEXT,
      allowNull: false,
    },
    Status: {
      type: Sequelize.ENUM("OPEN", "IN_PROGRESS", "WAITING_FOR_CUSTOMER", "RESOLVED", "CLOSED"),
      allowNull: false,
      defaultValue: "OPEN",
    },
    Priority: {
      type: Sequelize.ENUM("LOW", "MEDIUM", "HIGH", "URGENT"),
      allowNull: false,
      defaultValue: "MEDIUM",
    },
    CategoryId: {
      type: Sequelize.BIGINT,
      allowNull: true,
      references: { model: "Tbl_Category", key: "CategoryId" },
    },
    TypeId: {
      type: Sequelize.BIGINT,
      allowNull: true,
      references: { model: "Tbl_TicketType", key: "TypeId" },
    },
    AssignedTo: {
      type: Sequelize.BIGINT,
      allowNull: true,
      references: { model: "Tbl_User", key: "UserId" },
    },
    Product: {
      type: Sequelize.STRING,
      allowNull: true,
    },
    ProductReferenceNumber: {
      type: Sequelize.STRING,
      allowNull: true,
    },
    Tags: {
      type: Sequelize.JSON,
      allowNull: false,
      defaultValue: [],
    },
    ResolvedAt: {
      type: Sequelize.DATE,
      allowNull: true,
    },
    Is_Active: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

module.exports = Ticket;