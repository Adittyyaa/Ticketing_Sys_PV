const Sequelize = require("sequelize");
const db = require("../lib/database");

const Tag = db.define(
  "Tbl_Tag",
  {
    TagId: {
      type: Sequelize.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    Name: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true,
    },
    Color: {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: "#6B7280",
    },
    Is_Active: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

module.exports = Tag;