const Sequelize = require("sequelize");
const db = require("../lib/database");

const Category = db.define(
  "Tbl_Category",
  {
    CategoryId: {
      type: Sequelize.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    Name: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true,
    },
    Description: {
      type: Sequelize.TEXT,
      allowNull: true,
    },
    Color: {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: "#3B82F6",
    },
    Is_Active: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

module.exports = Category;