import { DataTypes } from 'sequelize';
import sequelize from '../lib/database.js';

const User = sequelize.define(
  "Tbl_User",
  {
    UserId: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    Email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true
      }
    },
    PasswordHash: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    FullName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Role: {
      type: DataTypes.ENUM("user", "admin", "agent"),
      allowNull: false,
      defaultValue: "user",
    },
    Phone: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    JobTitle: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    Company: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    AvatarUrl: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    EmailVerified: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    LastLogin: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    Is_Active: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

export default User;