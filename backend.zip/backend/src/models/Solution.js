const Sequelize = require("sequelize");
const db = require("../lib/database");

const Solution = db.define(
  "Tbl_Solution",
  {
    SolutionId: {
      type: Sequelize.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    Title: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    Description: {
      type: Sequelize.TEXT,
      allowNull: false,
    },
    Steps: {
      type: Sequelize.JSON,
      allowNull: false,
      defaultValue: [],
    },
    CategoryId: {
      type: Sequelize.BIGINT,
      allowNull: false,
      references: { model: "Tbl_Category", key: "CategoryId" },
    },
    Tags: {
      type: Sequelize.JSON,
      allowNull: false,
      defaultValue: [],
    },
    IsPublished: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    ViewCount: {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    HelpfulCount: {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    CreatedBy: {
      type: Sequelize.BIGINT,
      allowNull: false,
      references: { model: "Tbl_User", key: "UserId" },
    },
    Is_Active: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

module.exports = Solution;