const Sequelize = require("sequelize");
const db = require("../lib/database");

const Feedback = db.define(
  "Tbl_Feedback",
  {
    FeedbackId: {
      type: Sequelize.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    UserId: {
      type: Sequelize.BIGINT,
      allowNull: false,
      references: { model: "Tbl_User", key: "UserId" },
    },
    Category: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    Rating: {
      type: Sequelize.INTEGER,
      allowNull: false,
      validate: {
        min: 1,
        max: 5,
      },
    },
    Message: {
      type: Sequelize.TEXT,
      allowNull: false,
    },
    TicketId: {
      type: Sequelize.BIGINT,
      allowNull: true,
      references: { model: "Tbl_Ticket", key: "TicketId" },
    },
    Is_Active: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

module.exports = Feedback;