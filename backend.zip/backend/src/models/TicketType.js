const Sequelize = require("sequelize");
const db = require("../lib/database");

const TicketType = db.define(
  "Tbl_TicketType",
  {
    TypeId: {
      type: Sequelize.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    Name: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true,
    },
    Description: {
      type: Sequelize.TEXT,
      allowNull: true,
    },
    Icon: {
      type: Sequelize.STRING,
      allowNull: true,
    },
    Is_Active: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

module.exports = TicketType;