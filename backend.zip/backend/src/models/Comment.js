const Sequelize = require("sequelize");
const db = require("../lib/database");

const Comment = db.define(
  "Tbl_Comment",
  {
    CommentId: {
      type: Sequelize.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    TicketId: {
      type: Sequelize.BIGINT,
      allowNull: false,
      references: { model: "Tbl_Ticket", key: "TicketId" },
    },
    UserId: {
      type: Sequelize.BIGINT,
      allowNull: false,
      references: { model: "Tbl_User", key: "UserId" },
    },
    Content: {
      type: Sequelize.TEXT,
      allowNull: false,
    },
    IsInternal: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    Is_Active: {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: 'CreatedAt',
    updatedAt: 'UpdatedAt'
  }
);

module.exports = Comment;