import { ticketService } from '../services/ticketService.js'
import { asyncHandler } from '../middleware/errorHandler.js'

class TicketController {
  // ============================================
  // TICKET CRUD OPERATIONS
  // ============================================

  getTickets = asyncHandler(async (req, res) => {
    const user = req.user
    const { page, limit } = req.pagination
    const filters = {}

    // Extract filters from query parameters
    if (req.query.status) filters.status = req.query.status
    if (req.query.priority) filters.priority = req.query.priority
    if (req.query.category_id) filters.category_id = req.query.category_id
    if (req.query.assigned_to) filters.assigned_to = req.query.assigned_to
    if (req.query.search) filters.search = req.query.search
    
    // If user is not admin or agent, only show their own tickets
    if (user.role !== 'admin' && user.role !== 'agent') {
      filters.user_id = user.id
    }

    const result = await ticketService.getTickets(page, limit, filters)

    res.json({
      success: true,
      ...result
    })
  })

  getTicketById = asyncHandler(async (req, res) => {
    const user = req.user
    const ticketId = req.params.id

    const ticket = await ticketService.getTicketById(ticketId)

    if (!ticket) {
      return res.status(404).json({ 
        error: 'Ticket not found' 
      })
    }

    // Check if user can access this ticket
    if (user.role !== 'admin' && user.role !== 'agent' && ticket.user_id !== user.id) {
      return res.status(403).json({ 
        error: 'Access denied',
        message: 'You can only view your own tickets'
      })
    }

    res.json({
      success: true,
      ticket
    })
  })

  createTicket = asyncHandler(async (req, res) => {
    const user = req.user
    const ticketData = req.body

    const ticket = await ticketService.createTicket(user.id, ticketData)

    res.status(201).json({
      success: true,
      message: 'Ticket created successfully',
      ticket
    })
  })

  updateTicket = asyncHandler(async (req, res) => {
    const user = req.user
    const ticketId = req.params.id
    const updateData = req.body

    // First check if ticket exists and user has access
    const existingTicket = await ticketService.getTicketById(ticketId)
    if (!existingTicket) {
      return res.status(404).json({ 
        error: 'Ticket not found' 
      })
    }

    // Check permissions
    const canEdit = user.role === 'admin' || 
                   user.role === 'agent' || 
                   existingTicket.user_id === user.id

    if (!canEdit) {
      return res.status(403).json({ 
        error: 'Access denied',
        message: 'You can only edit your own tickets'
      })
    }

    // Regular users can only update certain fields
    if (user.role !== 'admin' && user.role !== 'agent') {
      const allowedFields = ['title', 'description', 'priority']
      const restrictedFields = Object.keys(updateData).filter(
        field => !allowedFields.includes(field)
      )
      
      if (restrictedFields.length > 0) {
        return res.status(403).json({
          error: 'Access denied',
          message: `You cannot update the following fields: ${restrictedFields.join(', ')}`
        })
      }
    }

    const updatedTicket = await ticketService.updateTicket(ticketId, updateData)

    res.json({
      success: true,
      message: 'Ticket updated successfully',
      ticket: updatedTicket
    })
  })

  deleteTicket = asyncHandler(async (req, res) => {
    const user = req.user
    const ticketId = req.params.id

    // Check if ticket exists
    const existingTicket = await ticketService.getTicketById(ticketId)
    if (!existingTicket) {
      return res.status(404).json({ 
        error: 'Ticket not found' 
      })
    }

    // Only admin can delete tickets, or users can delete their own open tickets
    const canDelete = user.role === 'admin' || 
                     (existingTicket.user_id === user.id && existingTicket.status === 'OPEN')

    if (!canDelete) {
      return res.status(403).json({ 
        error: 'Access denied',
        message: 'You can only delete your own open tickets'
      })
    }

    await ticketService.deleteTicket(ticketId)

    res.json({
      success: true,
      message: 'Ticket deleted successfully'
    })
  })

  // ============================================
  // TICKET OPERATIONS
  // ============================================

  searchTickets = asyncHandler(async (req, res) => {
    const user = req.user
    const { q: searchTerm } = req.query
    const { page, limit } = req.pagination

    if (!searchTerm) {
      return res.status(400).json({
        error: 'Search term is required',
        message: 'Please provide a search term using the "q" parameter'
      })
    }

    const filters = {}
    
    // Extract additional filters
    if (req.query.status) filters.status = req.query.status
    if (req.query.priority) filters.priority = req.query.priority
    
    // If user is not admin or agent, only search their own tickets
    if (user.role !== 'admin' && user.role !== 'agent') {
      filters.user_id = user.id
    }

    const result = await ticketService.searchTickets(searchTerm, filters, page, limit)

    res.json({
      success: true,
      searchTerm,
      ...result
    })
  })

  assignTicket = asyncHandler(async (req, res) => {
    const ticketId = req.params.id
    const { agentId } = req.body

    if (!agentId) {
      return res.status(400).json({
        error: 'Agent ID is required'
      })
    }

    // Check if ticket exists
    const existingTicket = await ticketService.getTicketById(ticketId)
    if (!existingTicket) {
      return res.status(404).json({ 
        error: 'Ticket not found' 
      })
    }

    const updatedTicket = await ticketService.assignTicket(ticketId, agentId)

    res.json({
      success: true,
      message: 'Ticket assigned successfully',
      ticket: updatedTicket
    })
  })

  // ============================================
  // USER-SPECIFIC OPERATIONS
  // ============================================

  getUserTickets = asyncHandler(async (req, res) => {
    const userId = req.user.id
    const { page, limit } = req.pagination
    const filters = {}

    // Extract filters from query parameters
    if (req.query.status) filters.status = req.query.status
    if (req.query.priority) filters.priority = req.query.priority
    if (req.query.category_id) filters.category_id = req.query.category_id

    const result = await ticketService.getUserTickets(userId, page, limit, filters)

    res.json({
      success: true,
      ...result
    })
  })

  getAssignedTickets = asyncHandler(async (req, res) => {
    const agentId = req.user.id
    const { page, limit } = req.pagination

    const result = await ticketService.getTicketsAssignedTo(agentId, page, limit)

    res.json({
      success: true,
      ...result
    })
  })

  // ============================================
  // ANALYTICS (for agents/admins)
  // ============================================

  getTicketAnalytics = asyncHandler(async (req, res) => {
    const analytics = await ticketService.getTicketAnalytics()
    const ticketsByCategory = await ticketService.getTicketsByCategory()
    const ticketsByAgent = await ticketService.getTicketsByAgent()

    res.json({
      success: true,
      analytics: {
        overview: analytics,
        byCategory: ticketsByCategory,
        byAgent: ticketsByAgent
      }
    })
  })

  getRecentTickets = asyncHandler(async (req, res) => {
    const limit = parseInt(req.query.limit) || 10
    const tickets = await ticketService.getRecentTickets(limit)

    res.json({
      success: true,
      tickets
    })
  })
}

export const ticketController = new TicketController()