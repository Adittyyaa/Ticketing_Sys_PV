import { authService } from '../services/authService.js'
import db from '../lib/database.js'
import { asyncHandler } from '../middleware/errorHandler.js'

class AuthController {
  // ============================================
  // HELPER METHODS
  // ============================================

  validatePasswordStrength(password) {
    if (!password || password.length < 8) {
      return { isValid: false, message: 'Password must be at least 8 characters long' }
    }
    return { isValid: true }
  }

  sanitizeUserResponse(user) {
    const { password_hash: _, ...safeUser } = user
    return safeUser
  }

  // ============================================
  // AUTHENTICATION ENDPOINTS
  // ============================================

  login = async (req, res) => {
    const requestId = req.id

    try {
      const { email, password } = req.body

      const result = await authService.login({ email, password })

      if (!result) {
        return res.status(401).json({ 
          success: false,
          error: 'Invalid credentials',
          message: 'Email or password is incorrect'
        })
      }

      console.log('User login successful', {
        controller: 'auth',
        method: 'login',
        userId: result.user.id,
        requestId: requestId,
      })

      res.json({
        success: true,
        message: 'Login successful',
        data: {
          user: result.user,
          token: result.token
        }
      })

    } catch (error) {
      console.error('Error in login Controller', {
        controller: 'auth',
        method: 'login',
        error: error.message,
        stack: error.stack,
        requestId: requestId,
      })

      return res.status(500).json({
        success: false,
        message: error.message,
      })
    }
  }

  register = async (req, res) => {
    const requestId = req.id

    try {
      const { email, password, full_name, phone, job_title, company } = req.body

      const result = await db.transaction(async (_transaction) => {
        const registrationResult = await authService.register({
          email,
          password,
          full_name,
          phone,
          job_title,
          company
        })
        return registrationResult
      })

      console.log('User registration successful', {
        controller: 'auth',
        method: 'register',
        userId: result.user.id,
        email: result.user.email,
        requestId: requestId,
      })

      return res.status(201).json({
        success: true,
        message: 'Registration successful',
        data: {
          user: result.user,
          token: result.token
        }
      })

    } catch (error) {
      console.error('Error in register Controller', {
        controller: 'auth',
        method: 'register',
        error: error.message,
        stack: error.stack,
        requestId: requestId,
      })

      if (error.message === 'User with this email already exists') {
        return res.status(409).json({
          success: false,
          message: error.message
        })
      }

      return res.status(500).json({
        success: false,
        message: error.message,
      })
    }
  }

  logout = async (req, res) => {
    const requestId = req.id

    try {
      const userId = req.user?.id

      console.log('User logout successful', {
        controller: 'auth',
        method: 'logout',
        userId: userId,
        requestId: requestId,
      })

      return res.json({
        success: true,
        message: 'Logout successful'
      })

    } catch (error) {
      console.error('Error in logout Controller', {
        controller: 'auth',
        method: 'logout',
        error: error.message,
        stack: error.stack,
        requestId: requestId,
      })

      return res.status(500).json({
        success: false,
        message: error.message,
      })
    }
  }

  // ============================================
  // TOKEN VALIDATION
  // ============================================

  validateToken = async (req, res) => {
    const requestId = req.id

    try {
      const user = req.user

      return res.json({
        success: true,
        data: {
          user: {
            id: user.id,
            email: user.email,
            full_name: user.full_name,
            role: user.role
          }
        }
      })

    } catch (error) {
      console.error('Error in validateToken Controller', {
        controller: 'auth',
        method: 'validateToken',
        error: error.message,
        stack: error.stack,
        requestId: requestId,
      })

      return res.status(500).json({
        success: false,
        message: error.message,
      })
    }
  }

  // ============================================
  // PASSWORD OPERATIONS
  // ============================================

  changePassword = asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body
    const userId = req.user.id

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        error: 'Validation failed',
        message: 'Current password and new password are required'
      })
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        error: 'Validation failed',
        message: 'New password must be at least 8 characters long'
      })
    }

    try {
      await authService.changePassword(userId, currentPassword, newPassword)

      res.json({
        success: true,
        message: 'Password changed successfully'
      })
    } catch (error) {
      if (error.message === 'Current password is incorrect') {
        return res.status(400).json({
          error: 'Invalid password',
          message: error.message
        })
      }
      throw error
    }
  })

  // ============================================
  // PASSWORD RESET
  // ============================================

  requestPasswordReset = asyncHandler(async (req, res) => {
    const { email } = req.body

    if (!email) {
      return res.status(400).json({
        error: 'Validation failed',
        message: 'Email is required'
      })
    }

    const resetToken = await authService.generateResetToken(email)

    if (!resetToken) {
      return res.json({
        success: true,
        message: 'If an account with that email exists, a password reset link has been sent'
      })
    }

    res.json({
      success: true,
      message: 'Password reset token generated',
      resetToken
    })
  })

  resetPassword = asyncHandler(async (req, res) => {
    const { resetToken, newPassword } = req.body

    if (!resetToken || !newPassword) {
      return res.status(400).json({
        error: 'Validation failed',
        message: 'Reset token and new password are required'
      })
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        error: 'Validation failed',
        message: 'Password must be at least 8 characters long'
      })
    }

    try {
      await authService.resetPassword(resetToken, newPassword)

      res.json({
        success: true,
        message: 'Password reset successfully'
      })
    } catch (error) {
      if (error.message === 'Invalid or expired reset token') {
        return res.status(400).json({
          error: 'Invalid token',
          message: error.message
        })
      }
      throw error
    }
  })

  // ============================================
  // USER PROFILE
  // ============================================

  getProfile = asyncHandler(async (req, res) => {
    const user = req.user

    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        phone: user.phone,
        job_title: user.job_title,
        company: user.company,
        avatar_url: user.avatar_url,
        created_at: user.created_at,
        updated_at: user.updated_at,
        last_login: user.last_login
      }
    })
  })
}

export const authController = new AuthController()
