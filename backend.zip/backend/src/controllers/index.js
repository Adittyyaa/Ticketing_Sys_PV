/**
 * Controller exports for easy importing
 * This file serves as the central export point for all controllers
 */

// Main Controllers
export * from './authController.js'
export * from './ticketController.js'
export * from './adminController.js'

// Import individual controller instances for direct use
import { authController } from './authController.js'
import { ticketController } from './ticketController.js'
import { adminController } from './adminController.js'

// Export controller instances grouped by functionality
export const controllers = {
  auth: authController,
  ticket: ticketController,
  admin: adminController
}

// Export specific controller methods for direct routing
export const authEndpoints = {
  login: authController.login,
  register: authController.register,
  logout: authController.logout,
  validateToken: authController.validateToken,
  changePassword: authController.changePassword,
  requestPasswordReset: authController.requestPasswordReset,
  resetPassword: authController.resetPassword,
  getProfile: authController.getProfile
}

export const ticketEndpoints = {
  getTickets: ticketController.getTickets,
  getTicketById: ticketController.getTicketById,
  createTicket: ticketController.createTicket,
  updateTicket: ticketController.updateTicket,
  deleteTicket: ticketController.deleteTicket,
  searchTickets: ticketController.searchTickets,
  assignTicket: ticketController.assignTicket,
  getUserTickets: ticketController.getUserTickets,
  getAssignedTickets: ticketController.getAssignedTickets,
  getTicketAnalytics: ticketController.getTicketAnalytics,
  getRecentTickets: ticketController.getRecentTickets
}

export const adminEndpoints = {
  getAllTickets: adminController.getAllTickets,
  getTicketById: adminController.getTicketById,
  updateTicket: adminController.updateTicket,
  deleteTicket: adminController.deleteTicket,
  bulkDeleteTickets: adminController.bulkDeleteTickets,
  assignTicket: adminController.assignTicket,
  getAllUsers: adminController.getAllUsers,
  getUserById: adminController.getUserById,
  updateUser: adminController.updateUser,
  updateUserRole: adminController.updateUserRole,
  deleteUser: adminController.deleteUser,
  verifyUserEmail: adminController.verifyUserEmail,
  getDashboardStats: adminController.getDashboardStats,
  getRecentActivity: adminController.getRecentActivity,
  getSystemHealth: adminController.getSystemHealth
}
