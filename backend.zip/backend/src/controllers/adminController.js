import { ticketService } from '../services/ticketService.js'
import { userService } from '../services/userService.js'
import { asyncHandler } from '../middleware/errorHandler.js'

class AdminController {
  // ============================================
  // ADMIN TICKET MANAGEMENT
  // ============================================

  getAllTickets = asyncHandler(async (req, res) => {
    const { page, limit } = req.pagination
    const filters = {}

    // Extract filters from query parameters
    if (req.query.status) filters.status = req.query.status
    if (req.query.priority) filters.priority = req.query.priority
    if (req.query.category_id) filters.category_id = req.query.category_id
    if (req.query.user_id) filters.user_id = req.query.user_id
    if (req.query.assigned_to) filters.assigned_to = req.query.assigned_to
    if (req.query.search) filters.search = req.query.search

    const result = await ticketService.getTickets(page, limit, filters)

    res.json({
      success: true,
      ...result
    })
  })

  getTicketById = asyncHandler(async (req, res) => {
    const ticketId = req.params.id
    const ticket = await ticketService.getTicketById(ticketId)

    if (!ticket) {
      return res.status(404).json({ 
        error: 'Ticket not found' 
      })
    }

    res.json({
      success: true,
      ticket
    })
  })

  updateTicket = asyncHandler(async (req, res) => {
    const ticketId = req.params.id
    const updateData = req.body

    const existingTicket = await ticketService.getTicketById(ticketId)
    if (!existingTicket) {
      return res.status(404).json({ 
        error: 'Ticket not found' 
      })
    }

    const updatedTicket = await ticketService.updateTicket(ticketId, updateData)

    res.json({
      success: true,
      message: 'Ticket updated successfully',
      ticket: updatedTicket
    })
  })

  deleteTicket = asyncHandler(async (req, res) => {
    const ticketId = req.params.id
    
    const existingTicket = await ticketService.getTicketById(ticketId)
    if (!existingTicket) {
      return res.status(404).json({ 
        error: 'Ticket not found' 
      })
    }

    await ticketService.deleteTicket(ticketId)

    res.json({
      success: true,
      message: 'Ticket deleted successfully'
    })
  })

  bulkDeleteTickets = asyncHandler(async (req, res) => {
    const { ticketIds } = req.body

    if (!Array.isArray(ticketIds) || ticketIds.length === 0) {
      return res.status(400).json({ 
        error: 'Invalid ticket IDs provided' 
      })
    }

    const deletedTickets = await ticketService.bulkDeleteTickets(ticketIds)

    res.json({
      success: true,
      message: `${deletedTickets.length} tickets deleted successfully`,
      deletedCount: deletedTickets.length
    })
  })

  assignTicket = asyncHandler(async (req, res) => {
    const ticketId = req.params.id
    const { agentId } = req.body

    if (!agentId) {
      return res.status(400).json({
        error: 'Agent ID is required'
      })
    }

    const existingTicket = await ticketService.getTicketById(ticketId)
    if (!existingTicket) {
      return res.status(404).json({ 
        error: 'Ticket not found' 
      })
    }

    const updatedTicket = await ticketService.assignTicket(ticketId, agentId)

    res.json({
      success: true,
      message: 'Ticket assigned successfully',
      ticket: updatedTicket
    })
  })

  // ============================================
  // USER MANAGEMENT
  // ============================================

  getAllUsers = asyncHandler(async (req, res) => {
    const { page, limit } = req.pagination
    const filters = {}

    // Extract filters
    if (req.query.role) filters.role = req.query.role
    if (req.query.email_verified !== undefined) {
      filters.email_verified = req.query.email_verified === 'true'
    }
    if (req.query.search) filters.search = req.query.search

    const result = await userService.getAllUsers(page, limit, filters)

    res.json({
      success: true,
      ...result
    })
  })

  getUserById = asyncHandler(async (req, res) => {
    const userId = req.params.id
    const user = await userService.getUserById(userId)

    if (!user) {
      return res.status(404).json({ 
        error: 'User not found' 
      })
    }

    // Remove password hash from response
    const { password_hash: _, ...safeUser } = user

    res.json({
      success: true,
      user: safeUser
    })
  })

  updateUser = asyncHandler(async (req, res) => {
    const userId = req.params.id
    const updateData = req.body

    const existingUser = await userService.getUserById(userId)
    if (!existingUser) {
      return res.status(404).json({ 
        error: 'User not found' 
      })
    }

    const updatedUser = await userService.updateUser(userId, updateData)
    
    // Remove password hash from response
    const { password_hash: _, ...safeUser } = updatedUser

    res.json({
      success: true,
      message: 'User updated successfully',
      user: safeUser
    })
  })

  updateUserRole = asyncHandler(async (req, res) => {
    const userId = req.params.id
    const { role } = req.body

    if (!role) {
      return res.status(400).json({
        error: 'Role is required'
      })
    }

    try {
      const updatedUser = await userService.updateUserRole(userId, role)
      
      // Remove password hash from response
      const { password_hash: _, ...safeUser } = updatedUser

      res.json({
        success: true,
        message: 'User role updated successfully',
        user: safeUser
      })
    } catch (error) {
      if (error.message === 'Invalid role' || error.message === 'User not found') {
        return res.status(400).json({
          error: error.message
        })
      }
      throw error
    }
  })

  deleteUser = asyncHandler(async (req, res) => {
    const userId = req.params.id
    
    // Prevent admin from deleting themselves
    if (userId === req.user.id) {
      return res.status(400).json({
        error: 'Cannot delete your own account'
      })
    }

    const existingUser = await userService.getUserById(userId)
    if (!existingUser) {
      return res.status(404).json({ 
        error: 'User not found' 
      })
    }

    await userService.deleteUser(userId)

    res.json({
      success: true,
      message: 'User deleted successfully'
    })
  })

  verifyUserEmail = asyncHandler(async (req, res) => {
    const userId = req.params.id

    try {
      const updatedUser = await userService.verifyUserEmail(userId)
      
      // Remove password hash from response
      const { password_hash: _, ...safeUser } = updatedUser

      res.json({
        success: true,
        message: 'User email verified successfully',
        user: safeUser
      })
    } catch (error) {
      if (error.message === 'User not found') {
        return res.status(404).json({
          error: error.message
        })
      }
      throw error
    }
  })

  // ============================================
  // ANALYTICS & REPORTS
  // ============================================

  getDashboardStats = asyncHandler(async (req, res) => {
    const [ticketAnalytics, userStats, ticketsByCategory, ticketsByAgent] = await Promise.all([
      ticketService.getTicketAnalytics(),
      userService.getUserStatistics(),
      ticketService.getTicketsByCategory(),
      ticketService.getTicketsByAgent()
    ])

    res.json({
      success: true,
      stats: {
        tickets: ticketAnalytics,
        users: userStats,
        ticketsByCategory,
        ticketsByAgent
      }
    })
  })

  getRecentActivity = asyncHandler(async (req, res) => {
    const limit = parseInt(req.query.limit) || 10
    const days = parseInt(req.query.days) || 7

    const [recentTickets, activeUsers] = await Promise.all([
      ticketService.getRecentTickets(limit),
      userService.getUsersWithRecentActivity(days)
    ])

    res.json({
      success: true,
      activity: {
        recentTickets,
        activeUsers
      }
    })
  })

  // ============================================
  // SYSTEM MANAGEMENT
  // ============================================

  getSystemHealth = asyncHandler(async (req, res) => {
    // You could add database connection checks, memory usage, etc.
    res.json({
      success: true,
      system: {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        version: process.version
      }
    })
  })
}

export const adminController = new AdminController()