/**
 * Security Middleware
 * Additional security layers for the application
 */

import rateLimit from 'express-rate-limit'
import helmet from 'helmet'

/**
 * Rate limiting configurations
 */
export const rateLimiters = {
  // General API rate limiting
  general: rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: {
      error: 'Too many requests',
      message: 'Please try again later'
    },
    standardHeaders: true,
    legacyHeaders: false
  }),

  // Authentication endpoints (more restrictive)
  auth: rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // limit each IP to 5 login attempts per windowMs
    message: {
      error: 'Too many authentication attempts',
      message: 'Please try again in 15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false
  }),

  // Password reset (very restrictive)
  passwordReset: rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3, // limit each IP to 3 password reset attempts per hour
    message: {
      error: 'Too many password reset attempts',
      message: 'Please try again in 1 hour'
    },
    standardHeaders: true,
    legacyHeaders: false
  }),

  // File upload endpoints
  upload: rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // limit each IP to 10 uploads per windowMs
    message: {
      error: 'Too many file uploads',
      message: 'Please try again later'
    },
    standardHeaders: true,
    legacyHeaders: false
  })
}

/**
 * Helmet security configuration
 */
export const helmetConfig = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"]
    }
  },
  crossOriginEmbedderPolicy: false,
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
})

/**
 * Request sanitization middleware
 */
export function sanitizeRequest(req, res, next) {
  // Remove potentially dangerous characters from query params
  if (req.query) {
    Object.keys(req.query).forEach(key => {
      if (typeof req.query[key] === 'string') {
        req.query[key] = req.query[key].replace(/[<>]/g, '')
      }
    })
  }

  // Remove potentially dangerous characters from body
  if (req.body && typeof req.body === 'object') {
    Object.keys(req.body).forEach(key => {
      if (typeof req.body[key] === 'string') {
        req.body[key] = req.body[key].trim()
      }
    })
  }

  next()
}

/**
 * IP whitelist middleware (for admin endpoints)
 */
export function ipWhitelist(allowedIPs = []) {
  return (req, res, next) => {
    if (allowedIPs.length === 0) {
      return next() // No whitelist configured, allow all
    }

    const clientIP = req.ip || req.connection.remoteAddress
    
    if (allowedIPs.includes(clientIP)) {
      next()
    } else {
      res.status(403).json({
        error: 'Access denied',
        message: 'Your IP address is not whitelisted'
      })
    }
  }
}

/**
 * Content type validation middleware
 */
export function validateContentType(allowedTypes = ['application/json']) {
  return (req, res, next) => {
    // Skip validation for GET requests
    if (req.method === 'GET') {
      return next()
    }

    const contentType = req.get('Content-Type')
    
    if (!contentType) {
      return res.status(400).json({
        error: 'Missing Content-Type header',
        message: 'Content-Type header is required'
      })
    }

    const isAllowed = allowedTypes.some(type => 
      contentType.toLowerCase().includes(type.toLowerCase())
    )

    if (!isAllowed) {
      return res.status(415).json({
        error: 'Unsupported Media Type',
        message: `Content-Type must be one of: ${allowedTypes.join(', ')}`
      })
    }

    next()
  }
}

/**
 * Request size validation
 */
export function validateRequestSize(maxSize = '10mb') {
  return (req, res, next) => {
    const contentLength = req.get('Content-Length')
    
    if (contentLength) {
      const sizeInBytes = parseInt(contentLength)
      const maxSizeInBytes = parseSize(maxSize)
      
      if (sizeInBytes > maxSizeInBytes) {
        return res.status(413).json({
          error: 'Request too large',
          message: `Request size exceeds ${maxSize} limit`
        })
      }
    }

    next()
  }
}

/**
 * Helper function to parse size strings
 */
function parseSize(size) {
  const units = { b: 1, kb: 1024, mb: 1024 * 1024, gb: 1024 * 1024 * 1024 }
  const match = size.toLowerCase().match(/^(\d+)(b|kb|mb|gb)$/)
  
  if (!match) return 0
  
  return parseInt(match[1]) * units[match[2]]
}

export default {
  rateLimiters,
  helmetConfig,
  sanitizeRequest,
  ipWhitelist,
  validateContentType,
  validateRequestSize
}