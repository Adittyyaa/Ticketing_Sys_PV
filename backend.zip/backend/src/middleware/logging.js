/**
 * Logging Middleware
 * Request/response logging and audit trails
 */

import morgan from 'morgan'

/**
 * Custom token for user ID in logs
 */
morgan.token('user-id', (req) => {
  return req.user ? req.user.id : 'anonymous'
})

/**
 * Custom token for user role in logs
 */
morgan.token('user-role', (req) => {
  return req.user ? req.user.role : 'none'
})

/**
 * Custom token for request duration
 */
morgan.token('duration', (req, _res) => {
  if (!req._startTime) return '0ms'
  const duration = Date.now() - req._startTime
  return `${duration}ms`
})

/**
 * Development logging format
 */
const developmentFormat = morgan.compile([
  ':method :url :status :res[content-length] - :response-time ms',
  '[:user-id/:user-role]'
].join(' '))

/**
 * Production logging format
 */
const productionFormat = morgan.compile([
  ':remote-addr - :remote-user [:date[clf]]',
  '":method :url HTTP/:http-version" :status :res[content-length]',
  '":referrer" ":user-agent" :user-id/:user-role :duration'
].join(' '))

/**
 * Get logging middleware based on environment
 */
export function getLoggerMiddleware() {
  if (process.env.NODE_ENV === 'production') {
    return morgan(productionFormat, {
      stream: {
        write: (message) => {
          // In production, you might want to write to a file or external service
          console.log(message.trim())
        }
      }
    })
  } else {
    return morgan(developmentFormat)
  }
}

/**
 * Request timing middleware
 */
export function requestTiming(req, res, next) {
  req._startTime = Date.now()
  next()
}

/**
 * Audit logging for sensitive operations
 */
export function auditLogger(action) {
  return (req, res, next) => {
    const originalSend = res.send
    
    res.send = function(data) {
      // Log the action after successful response
      if (res.statusCode < 400) {
        console.log('AUDIT:', {
          action,
          user: req.user ? {
            id: req.user.id,
            email: req.user.email,
            role: req.user.role
          } : null,
          timestamp: new Date().toISOString(),
          ip: req.ip,
          userAgent: req.get('User-Agent'),
          method: req.method,
          url: req.originalUrl,
          statusCode: res.statusCode
        })
      }
      
      originalSend.call(this, data)
    }
    
    next()
  }
}

/**
 * API access logger for rate limiting analysis
 */
export function apiAccessLogger(req, res, next) {
  const logData = {
    timestamp: new Date().toISOString(),
    method: req.method,
    url: req.originalUrl,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    userId: req.user ? req.user.id : null,
    referer: req.get('Referer') || null
  }

  // In production, you might want to store this in a database or send to analytics
  console.log('API_ACCESS:', JSON.stringify(logData))
  
  next()
}

export default getLoggerMiddleware