import { authService } from '../services/authService.js'

/**
 * Authentication middleware
 * Validates JWT token and attaches user to request
 */
export async function authenticate(req, res, next) {
  try {
    const user = await authService.validateAuthToken(req.headers.authorization)
    
    if (!user) {
      return res.status(401).json({ 
        error: 'Authentication required' 
      })
    }

    req.user = user
    next()
  } catch (error) {
    console.error('Authentication middleware error:', error)
    res.status(401).json({ 
      error: 'Invalid authentication token' 
    })
  }
}

/**
 * Admin authorization middleware
 * Requires user to be authenticated and have admin role
 */
export async function requireAdmin(req, res, next) {
  try {
    const user = await authService.validateAuthToken(req.headers.authorization)
    
    if (!user) {
      return res.status(401).json({ 
        error: 'Authentication required' 
      })
    }

    if (user.role !== 'admin') {
      return res.status(403).json({ 
        error: 'Admin access required' 
      })
    }

    req.user = user
    next()
  } catch (error) {
    console.error('Admin middleware error:', error)
    res.status(403).json({ 
      error: 'Access denied' 
    })
  }
}

/**
 * Agent authorization middleware
 * Requires user to be authenticated and have admin or agent role
 */
export async function requireAgent(req, res, next) {
  try {
    const user = await authService.validateAuthToken(req.headers.authorization)
    
    if (!user) {
      return res.status(401).json({ 
        error: 'Authentication required' 
      })
    }

    if (user.role !== 'admin' && user.role !== 'agent') {
      return res.status(403).json({ 
        error: 'Agent access required' 
      })
    }

    req.user = user
    next()
  } catch (error) {
    console.error('Agent middleware error:', error)
    res.status(403).json({ 
      error: 'Access denied' 
    })
  }
}

/**
 * Ownership middleware
 * Allows access if user owns the resource or has elevated privileges
 */
export function requireOwnershipOrElevated(_resourceUserIdField = 'user_id') {
  return async (req, res, next) => {
    try {
      // User should already be authenticated by previous middleware
      if (!req.user) {
        return res.status(401).json({ 
          error: 'Authentication required' 
        })
      }

      // Admin and agents can access any resource
      if (req.user.role === 'admin' || req.user.role === 'agent') {
        return next()
      }

      // For regular users, we'll check ownership in the controller
      // This middleware just ensures they're authenticated
      next()
    } catch (error) {
      console.error('Ownership middleware error:', error)
      res.status(500).json({ 
        error: 'Internal server error' 
      })
    }
  }
}